const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const FacebookStrategy = require('passport-facebook');
const config = require('./configuration');
const User = require('../models/user_model');
const jwt = require('jsonwebtoken');
const bcrypt= require('bcrypt');


passport.use(
    new GoogleStrategy({
        // options for google strategy
        clientID: config.clientID,
        clientSecret: config.clientSecret,
        callbackURL: '/auth/google/redirect',
        profileFields: ['id', 'displayName', 'photos', 'email']
    }, (accessToken, refreshToken, profile, done) => {
        // passport callback function
        //console.log('passport callback function fired:');
        // console.log(profile);


        var newUser =  new User({
          fullname : profile.displayName,
          email    : profile.emails[0].value
        });

        var token = jwt.sign({_id:newUser._id , fullname:newUser.fullname , email:newUser.email },config.secret);
        newUser.token = token ;
        newUser.save().then((newUser)=>{
          console.log("User Created!");
          done(null,newUser);
        }).catch((err)=>{
          console.log(err);
        });
    })
);

passport.use(
  new FacebookStrategy({
    clientID:config.AppID,
    clientSecret:config.AppSecret,
    callbackURL:'/auth/google/redirect'
  },(accessToken,refreshToken,profile,done)=>{

    var newUser =  new User({
      fullname : profile.displayName,
      email    : profile.emails[0].value
    });

    var token = jwt.sign({_id:newUser._id , fullname:newUser.fullname , email:newUser.email },config.secret);
    newUser.token = token ;
    newUser.save().then((newUser)=>{
      console.log("User Created!");
      done(null,newUser);
    }).catch((err)=>{
      console.log(err);
    });
})

);

passport.serializeUser((user,done)=>{
  done(null,user.id);
});

passport.deserializeUser((id,done)=>{
  User.findById(id).then((user)=>{
    done(null,user);
  });
});
