module.exports = {

    cookieKey:'randomkeyhere',

    //mongo db connection
    url : "mongodb://localhost:27017/RegisJwt",
    secret : "Secret",

    //sending emailAddress
    central_mail:'youremailhere@usedforsendingmails.com',
    central_password:'yourpassword',

    //Google client id and secret
    clientID:"Google client id after registering your app with google to use api",
    clientSecret:"google client secret",

    //fb appid and Secret
    AppID:"fb app id",
    AppSecret:"fb app secret"
};
