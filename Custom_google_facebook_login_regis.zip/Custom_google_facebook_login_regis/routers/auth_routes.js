const router = require('express').Router();
const passport = require('passport');
const passportSetup = require('../config/passport_setup');

// auth with google+
router.get('/google', passport.authenticate('google', {
    scope: ['profile','email']
}));
//we can add more stuff ['profile','age'] etc

//--------------------------------------------------
// callback route for google to redirect to
// hand control to passport to use code to grab profile info

// //google/redirect callback route for google to redirect to
// //take the code and exchange it for info
// //passport.authenticate here goes to google  with code in exchange for info and it gets and the callback function in passport setup is fired

router.get('/google/redirect', passport.authenticate('google'), (req, res) => {
    res.send(req.user.fullname + ",Congratulations you are now registered with "+req.user.email);
});


//logout
router.get('/logout',(req,res)=>{
  res.send("Logging out!");
});


//--------------FB-----------------------//
router.get('/fb',passport.authenticate('facebook',{
  // scope:['user_friends']
})
);

router.get('/fb/redirect',passport.authenticate('facebook'),(req,res) =>{
  res.send("Fb login");
});

module.exports = router;
